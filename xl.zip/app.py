# -*- coding: utf-8 -*-
import os
import sys
import platform
from xlpy import *

def main_menu():
    clear()
    print(
         "\n#############################################"
         "\n#############################################"
         "\n           TEMBAK PAKET XL TERMUX"
         "\n     Recode By     : X-Mr.R4h1M"
         "\n     Contact    : user.rahim@gmail.com"
         "\n#############################################"
         "\n#############################################"
        "\nSilahkan pilih menu Anda :"
        "\n[1] Paket Pembelian" + 
        "\n[2] Req OTP Code (Mohon Maaf Ini Lagi Rusak)"  +
        "\n[0] Keluar"
    )
    choice = str(input(" >> "))
    exec_menu(choice)
    return

def exec_menu(choice):
    clear()
    if(choice == ''):
        menu_actions['main']()
    else:
        try:
            menu_actions[choice]()
        except KeyError:
            print("Invalid selection, please try again.\n")
            menu_actions['main']()
    return

def menu_1():
    print(
         "\n#############################################"
         "\n#############################################"
         "\n           TEMBAK PAKET XL TERMUX"
         "\n     Recode By     : X-Mr.R4h1M"
         "\n     Contact    : user.rahim@gmail.com"
         "\n#############################################"
         "\n#############################################"
         "\nPaket Pembelian :"
    )
    msisdn = str(input("Masukan Nomer Anda : "))
    passwd = str(input("Masukan OTP : "))
    print(
        "Daftar Paket XL Service ID:"
        "\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"
        "\n[1] Xtra 10GB(Rp. 59.900) ID : 8211183" +
        "\n[2] XtraKuota 30GB (Rp. 10.000) ID : 8110577" +
        "\n[3] Xtra Lite 5GB (Rp. 30.000) ID : 8211011" +
        "\n[4] Xtra Lite 9GB (Rp. 53.000) ID : 8211012" +
        "\n[5] Xtra Lite 3GB (Rp. 20.00p) ID : 8211010" +
        "\n[6] Kuota 700MB (Rp. 10.000) ID : 8211170" +
        "\n[7] Xtra Lite 25GB (Rp. 95.0000) ID : 8211014" +
        "\n[8] Xtra Lite 17GB (Rp. 92.000) ID : 8211013" +
        "\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"
        )
    serviceid = str(input("Masukan Service ID Di Atas Ex:8123xxx : "))
    xl = XL(msisdn)
    r = xl.loginWithPassword(passwd)
    if(r != False):
        print(xl.purchasePackage(serviceid)['message'])
    else:
        print("Login failed try again")
    decision = str(input("Ingin Mengulangi Prosesnya Masukan [Y] Kembali ke Menu Utama [N]? >> "))
    menu_actions['main']() if(decision in ['N','n']) else menu_actions['1']()
    return
        
def menu_2():
    clear()
    print(
        "\n#############################################"
         "\n################################################"
         "\n           TEMBAK PAKET XL TERMUX"
         "\n     Recode By     : X-Mr.R4h1M"
         "\n     Contact    : user.rahim@gmail.com"
         "\n#############################################"
         "\n#############################################"
         "\nRequest OTP Code :"
    )
    msisdn = str(input("Masukan Nomer Anda >> "))
    xl = XL(msisdn)
    print(xl.reqPassword()['message'])
    decision = str(input("Ingin Mengulangi Prosesnya Masukan [Y] Kembali ke Menu Utama [N]? >> "))
    menu_actions['main']() if(decision in ['N','n']) else menu_actions['2']()
    return

def exit():
    sys.exit()

def clear():
    return os.system("cls") if (platform.system() == 'Windows') else os.system("clear")

menu_actions = {
    "main" : main_menu,
    "1" : menu_1,
    "2" : menu_2,
    "0" : exit
}


if __name__ == "__main__":
    main_menu()
    
